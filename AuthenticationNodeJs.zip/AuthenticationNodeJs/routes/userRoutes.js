import express from "express";
import UserController from "../controllers/userController.js";



const router=express.Router()


//public route-->without login access
router.route("/register").post(UserController.userRegistration)

router.route("/login").post(UserController.userLogin)




//private route-->with login access

export default router